package com.example.deltatask1new;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button op1= findViewById(R.id.op1);
        Button op2= findViewById(R.id.op2);
        Button op3= findViewById(R.id.op3);
        Button op4= findViewById(R.id.op4);
        Button op5= findViewById(R.id.op5);
        Button op6= findViewById(R.id.op6);
        Button op7= findViewById(R.id.op7);
        Button op8= findViewById(R.id.op8);
        Button op9= findViewById(R.id.op9);
        Button op10= findViewById(R.id.op10);
        Button a1= findViewById(R.id.a1);
        Button a2= findViewById(R.id.a2);
        Button a3= findViewById(R.id.a3);
        Button a4= findViewById(R.id.a4);
        Button a5= findViewById(R.id.a5);
        Button b1= findViewById(R.id.b1);
        Button b2= findViewById(R.id.b2);
        Button b3= findViewById(R.id.b3);
        Button b4= findViewById(R.id.b4);
        Button b5= findViewById(R.id.b5);
        int x1=0;
        int x2=0;
        int x3=0;
        int x4=0;
        int x5=0;
        int x6=0;
        int x7=0;
        int x8=0;
        int x9=0;
        int x10=0;
        final int[] ansc = {0};
        
        op1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int x1 = 1;
            }
        });
        op2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int x2 =1;
            }
        });
        op3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int x3 =3;
            }
        });
        op4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int x4 =4;
            }
        });
        op5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int x5 =5;
            }
        });
        op6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int x6 =6;
            }
        });
        op7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int x7 =6;
            }
        });
        op8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int x8 =4;
            }
        });
        op9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int x9 =3;
            }
        });
        op10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int x10 =5;
            }
        });
        a1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (x5==5 || x10==5){
                    ansc[0] +=1;
                }
//                else{
//                    boolean answer4 = false;
//                }
            }
        });
        a2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (x4==4 || x8==8){
                    ansc[0] +=1;                }
//                else{
//                    boolean answer3 = false;
//                }
            }
        });
        a3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (x3==3 || x9==3){
                    ansc[0] +=1;
                }
//                else{
//                    boolean answer2 = false;
//                }
            }
        });
        a4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (x1==1 || x2==1){
                    ansc[0] +=1;
                }
//                else{
//                    boolean answer1 = false;
//                }

            }
        });
        a5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (x6==6 || x7==6){
                    ansc[0] +=1;
                }
//                else{
//                    boolean answer5 = false;
//                }
            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (x5==5 || x10==5){
                    ansc[0] +=1;
                }
//                else{
//                    boolean answer4 = false;
//                }
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (x4==4 || x8==8){
                    ansc[0] +=1;
                }
//                else{
//                    boolean answer3 = false;
//                }
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (x3==3 || x9==3){
                    ansc[0] +=1;
                }
//                else{
//                    boolean answer2 = false;
//                }
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (x1==1 || x2==1){
                    ansc[0] +=1;
                }
//                else{
//                    boolean answer1 = false;
//                }
            }
        });
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (x6==6 || x7==6){
                    ansc[0] +=1;
                }
//                else{
//                    boolean answer5 = false;
//                }

            }
        });
        if (ansc.equals(5)) {
            System.out.println("Game over");

        }
    }}